const CONFIG = {
  API_KEY: 'apiKey=4b520dd6be084baeacbaeb88744b0059',
  BASE_URL: 'https://api.spoonacular.com/',
  NUMBER_PAGE: 'number=8',
  DATABASE_NAME: 'anaksehat-database',
  DATABASE_VERSION: 1,
  OBJECT_STORE_NAME: 'recipes',
  CACHE_NAME: new Date().toISOString(),
};

export default CONFIG;
